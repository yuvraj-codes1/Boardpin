// api/label.js
// Vercel Serverless Function — generates a short, clean label for a saved link
// using Google's Gemini API. The API key stays server-side; the browser never sees it.
//
// Required environment variable (set in Vercel dashboard, NOT in this file):
//   GEMINI_API_KEY = your Google AI Studio key (no "nvapi-" prefix, just the raw key)
//
// Model: gemini-2.5-flash-lite — the current free-tier, low-latency Gemini model.
// It's the cheapest/fastest stable Gemini model with vision support, which keeps
// this function fast, free at this usage volume, and able to actually look at a
// thumbnail image (e.g. YouTube) instead of guessing from text alone.

const GEMINI_MODEL = 'gemini-2.5-flash-lite';

export default async function handler(req, res) {
  // CORS: allow this to be called from the deployed board itself
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing GEMINI_API_KEY. Add it in Vercel → Project Settings → Environment Variables.' });
  }

  const { url, caption, platform, imageUrl } = req.body || {};
  if (!url) {
    return res.status(400).json({ error: 'Missing url' });
  }

  // A "caption" that's just the URL itself (or the URL plus a couple of stray
  // characters) is not real signal — Instagram/TikTok often share exactly this.
  // Strip any URL-shaped substrings out, then require a few real words to remain.
  const captionWithoutUrls = (caption || '').replace(/https?:\/\/\S+/gi, '').trim();
  const hasCaption = captionWithoutUrls.length >= 6 && /[a-zA-Z]{3,}/.test(captionWithoutUrls);
  const hasImage = !!imageUrl;

  // If we have neither a real caption nor an image, there is nothing for the model
  // to actually read — asking it to "label this link" from a bare share-shortlink
  // (e.g. instagram.com/reel/DY-) just invites it to invent a plausible-sounding
  // topic instead of admitting it doesn't know. Refuse up front instead of guessing.
  if (!hasCaption && !hasImage) {
    return res.status(200).json({ label: null, reason: 'no_signal' });
  }

  // Keep the prompt as short as possible — fewer input tokens = faster + cheaper + stays
  // comfortably inside the free tier even with frequent use.
  const textParts = [
    `Label this ${platform || 'web'} link for a bookmark app, using ONLY the information given below.`,
    hasCaption ? `Caption: ${captionWithoutUrls.slice(0, 250)}` : null,
    `URL: ${url}`,
    hasImage ? `An image from the content is attached — base the label on what it actually shows.` : null,
    `Reply with ONLY a 2-6 word title describing the actual content. No quotes, no hashtags, no emoji.`,
    `If the caption and image (if any) genuinely don't tell you what this is about, reply with exactly: UNKNOWN`
  ].filter(Boolean).join('\n');

  const parts = [{ text: textParts }];

  // If we have a fetchable image (currently only YouTube thumbnails are reliably
  // public/CORS-safe), pass it in as real visual input — this is the genuine
  // upgrade Gemini gives us over a text-only model.
  if (imageUrl) {
    try {
      const imgRes = await fetch(imageUrl);
      if (imgRes.ok) {
        const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
        const buffer = await imgRes.arrayBuffer();
        const base64 = Buffer.from(buffer).toString('base64');
        // Small safety cap so we never send a huge payload / burn excess tokens
        if (base64.length < 2_000_000) {
          parts.push({ inline_data: { mime_type: contentType, data: base64 } });
        }
      }
    } catch (e) {
      console.warn('Thumbnail fetch failed, continuing text-only:', e.message);
    }
  }

  try {
    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts }],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 20,       // labels are short — keeps output cheap
            thinkingConfig: { thinkingBudget: 0 } // disable "thinking" tokens, we just want the answer
          }
        })
      }
    );

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      console.error('Gemini API error:', geminiRes.status, errText);
      return res.status(502).json({ error: 'AI labeling service failed', detail: errText });
    }

    const data = await geminiRes.json();
    let label = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';
    // Strip stray quotes/markdown the model sometimes adds despite instructions
    label = label.replace(/^["'*_]+|["'*_]+$/g, '').trim();

    if (!label || label.toUpperCase() === 'UNKNOWN') {
      return res.status(200).json({ label: null, reason: 'unknown' });
    }

    return res.status(200).json({ label });
  } catch (err) {
    console.error('label.js error:', err);
    return res.status(500).json({ error: 'Unexpected server error' });
  }
}
