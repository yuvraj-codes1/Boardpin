# Security Hardening Summary — The Board

This documents the security changes made to this app and what to verify before
deploying.

## 1. Rate limiting (`api/_rateLimit.js`, applied in `api/label.js`)

- Per-IP sliding-window limiter: **20 requests/minute** and **60/hour** on
  `POST /api/label` (the only server-controlled endpoint in this app — the
  Supabase REST/auth API is Supabase's own infrastructure, see note below).
- Returns `429` with a `Retry-After` header and JSON body `{ error, retryAfterSeconds }`
  when exceeded, plus `X-RateLimit-Limit` / `X-RateLimit-Remaining` headers on
  every response.
- **Scaling note:** the limiter store is in-memory per serverless instance.
  This meaningfully blocks scripted abuse and retry storms from a single IP
  under normal/small-scale traffic, but if this app grows to serious traffic
  across many concurrent instances, swap the store for a shared backend
  (Upstash Redis + `@upstash/ratelimit`, or Vercel KV). The `enforceRateLimit()`
  call signature won't need to change.
- Why no user-based limiting: this endpoint doesn't require auth (it doesn't
  read/write user data), so there's no reliable user identity to key on beyond
  IP. If you add auth to this endpoint later, add a second limiter keyed on
  user ID alongside the IP one.

## 2. Input validation & sanitization (`api/_validate.js`, applied in `api/label.js`)

Schema-based, allow-list validation on every field of the `/api/label` request body:

- Rejects any field not in `{ url, caption, platform, imageUrl }` (no silent
  mass-assignment surprises later).
- `url` / `imageUrl`: must be strings, ≤2048 chars, valid `http(s)://` only
  (blocks `javascript:`, `data:`, etc.).
- `imageUrl` additionally must resolve to an allow-listed host
  (`i.ytimg.com` only) — an SSRF guard, since this endpoint fetches the URL
  server-side.
- `caption`: string, ≤500 chars, control characters stripped.
- `platform`: must be one of a fixed enum matching what the client actually
  detects.
- The Gemini prompt itself now explicitly tells the model to treat caption/URL
  as data, not instructions (basic prompt-injection mitigation), and the
  returned label is hard-capped to 80 characters regardless of what the model
  returns.

Client-side (`the-board.html`) also gained matching limits for UX and
defense-in-depth (title ≤200 chars, tags ≤15 tags of ≤40 chars each, URL
≤2048 chars) — **these are not a substitute for server-side/database
enforcement.** See "Remaining action items" below.

## 3. API key handling (`api/label.js`)

- `GEMINI_API_KEY` was already read from `process.env` and never sent to the
  client — this was correct in the original code and is unchanged.
- Hardened: the client now gets a generic `"AI labeling is temporarily unavailable"`
  message instead of any config detail if the key is missing; upstream Gemini
  error bodies are logged server-side only and never forwarded to the client
  (previously the raw error text was returned in the response).
- Added key rotation instructions as comments directly in `api/label.js`.
- The Supabase `SUPABASE_ANON_KEY` embedded in `the-board.html` is **not** a
  secret — Supabase's anon/public key is designed to be shipped client-side
  and is safe as long as Row Level Security (RLS) policies are correctly
  configured on the `links` and `categories` tables (see below).

## 4. Cross-site scripting (XSS) fixes in `the-board.html`

Found and fixed several places where user-controlled data (link URLs, custom
category names, YouTube-derived IDs) was inserted into HTML without escaping:

- Card `href` now only ever renders as a real link if the stored URL is
  genuinely `http(s)://`; anything else falls back to `#`.
- Inline `onclick="..."` handlers (`copyPin`, `startEditPin`) now HTML-escape
  *and* escape single quotes, since a crafted URL/id could otherwise break out
  of the inline handler's string literal.
- Category labels (user-defined, via "Manage categories") are now escaped in
  all four places they're rendered: card view, card edit view, the category
  `<select>`, and the filter chips.
- YouTube thumbnail `src` is now only built from a `youtubeId` that matches
  YouTube's actual ID shape (`[a-zA-Z0-9_-]{6,20}`) — previously a crafted
  `youtu.be/"><script>...` URL could inject through the unvalidated ID.

## 5. Security headers (`vercel.json`, new file)

Added via Vercel's `headers` config, applied to every route:
`X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`,
`Referrer-Policy: strict-origin-when-cross-origin`, a restrictive
`Permissions-Policy`, HSTS, and a `Content-Security-Policy`.

**CSP tradeoff, stated plainly:** this app has no build step — all app logic
is one inline `<script>` block and it uses inline `onclick=` handlers and
inline `style=` attributes throughout. A strict CSP (no `unsafe-inline`) would
require restructuring the app to use external script files and
`addEventListener` instead of inline handlers. The shipped CSP still:
- blocks any script/style from a host not on the explicit allow-list
  (`cdn.jsdelivr.net` for Supabase's SDK, Google Fonts, `i.ytimg.com`,
  `www.google.com` favicons, YouTube oEmbed, and your Supabase project),
- blocks framing entirely (`frame-ancestors 'none'`),
- blocks `<object>`/plugin content entirely,
- restricts `base-uri` and `form-action` to same-origin.

If you're willing to refactor inline handlers/styles into external files, I'm
happy to do that next to drop `unsafe-inline` from the CSP entirely.

## Remaining action items (outside this repo, needs your Supabase dashboard)

This repo doesn't include your Supabase project's Row Level Security
policies — please verify:
1. RLS is **enabled** on both `links` and `categories` tables.
2. Policies restrict `select`/`insert`/`update`/`delete` to rows where
   `user_id = auth.uid()` (or equivalent), so one user can never read/write
   another user's rows even though the anon key is public.
3. Consider adding database-level `check` constraints mirroring the client
   limits above (e.g. `char_length(title) <= 200`), since a client-side check
   can always be bypassed by calling the Supabase API directly with valid
   credentials.
4. Rotate `GEMINI_API_KEY` if it was ever exposed prior to this review
   (committed to git history, shared in a screenshot, etc.) — see rotation
   steps in `api/label.js`.
