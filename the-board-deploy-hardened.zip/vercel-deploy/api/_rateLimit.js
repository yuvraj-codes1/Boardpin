// api/_rateLimit.js
// ---------------------------------------------------------------------------
// Lightweight sliding-window rate limiter for Vercel serverless functions.
//
// IMPORTANT SCALING NOTE (read before relying on this in high-traffic prod):
// Vercel serverless functions are stateless between cold starts and can run
// as multiple concurrent instances. This in-memory store is per-instance, so
// under heavy concurrent load the "real" effective limit across all instances
// can be higher than the configured limit. For a single-function hobby/small
// app (like this one) this still meaningfully blocks scripted abuse and
// accidental retry storms from one IP, which covers the realistic threat
// model here. If this app grows to serious traffic, swap the Store class
// below for a shared backend (e.g. Upstash Redis / @upstash/ratelimit, or
// Vercel KV) — the checkRateLimit() call signature will not need to change.
// ---------------------------------------------------------------------------

// key -> array of timestamps (ms) of requests within the current window
const hits = new Map();

// Periodically sweep old entries so the Map doesn't grow unbounded across
// a long-lived warm instance.
const SWEEP_INTERVAL_MS = 5 * 60 * 1000;
let lastSweep = Date.now();

function sweep(now) {
  if (now - lastSweep < SWEEP_INTERVAL_MS) return;
  lastSweep = now;
  for (const [key, timestamps] of hits.entries()) {
    const fresh = timestamps.filter(t => now - t < SWEEP_INTERVAL_MS);
    if (fresh.length === 0) hits.delete(key);
    else hits.set(key, fresh);
  }
}

/**
 * Check + record a hit against a rate limit key.
 * @param {string} key - unique identifier for the limited subject (e.g. `ip:1.2.3.4`)
 * @param {object} opts
 * @param {number} opts.limit - max requests allowed per window
 * @param {number} opts.windowMs - window size in milliseconds
 * @returns {{ allowed: boolean, remaining: number, retryAfterSeconds: number }}
 */
function checkRateLimit(key, { limit, windowMs }) {
  const now = Date.now();
  sweep(now);

  const timestamps = (hits.get(key) || []).filter(t => now - t < windowMs);
  const allowed = timestamps.length < limit;

  if (allowed) {
    timestamps.push(now);
    hits.set(key, timestamps);
  }

  const remaining = Math.max(0, limit - timestamps.length);
  const oldest = timestamps[0] || now;
  const retryAfterSeconds = allowed ? 0 : Math.max(1, Math.ceil((windowMs - (now - oldest)) / 1000));

  return { allowed, remaining, retryAfterSeconds };
}

/**
 * Extract the best-effort client IP from a Vercel request object.
 * Vercel sets x-forwarded-for behind its own proxy, so this is trustworthy
 * (it isn't directly attacker-controlled the way it would be with no proxy).
 */
function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length > 0) {
    // x-forwarded-for can be a comma-separated list; the first entry is the
    // original client as seen by Vercel's edge network.
    return fwd.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || 'unknown';
}

/**
 * Apply a rate limit to a request/response pair. Sends a 429 with a
 * Retry-After header and JSON body if the limit is exceeded.
 * @returns {boolean} true if the request should continue, false if a 429 was already sent
 */
function enforceRateLimit(req, res, { key, limit, windowMs }) {
  const { allowed, remaining, retryAfterSeconds } = checkRateLimit(key, { limit, windowMs });

  res.setHeader('X-RateLimit-Limit', String(limit));
  res.setHeader('X-RateLimit-Remaining', String(remaining));

  if (!allowed) {
    res.setHeader('Retry-After', String(retryAfterSeconds));
    res.status(429).json({
      error: 'Too many requests. Please slow down and try again shortly.',
      retryAfterSeconds
    });
    return false;
  }
  return true;
}

export { checkRateLimit, getClientIp, enforceRateLimit };
