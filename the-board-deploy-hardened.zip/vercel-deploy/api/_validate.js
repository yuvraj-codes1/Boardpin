// api/_validate.js
// ---------------------------------------------------------------------------
// Small dependency-free schema validation helpers, following OWASP input
// validation guidance:
//   - allow-list (not deny-list) validation wherever possible
//   - explicit type + length checks on every field
//   - reject unknown/unexpected fields instead of silently ignoring them
//   - validate on the server, never trust client-side checks alone
// ---------------------------------------------------------------------------

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
  }
}

/**
 * Validate that `value` is a safe http(s) URL.
 * Rejects javascript:, data:, file:, and other non-http(s) schemes to guard
 * against XSS / SSRF-style payloads disguised as a "url" field.
 */
function assertHttpUrl(value, fieldName, { maxLength = 2048 } = {}) {
  if (typeof value !== 'string') {
    throw new ValidationError(`${fieldName} must be a string`);
  }
  if (value.length === 0 || value.length > maxLength) {
    throw new ValidationError(`${fieldName} must be between 1 and ${maxLength} characters`);
  }
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    throw new ValidationError(`${fieldName} must be a valid URL`);
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new ValidationError(`${fieldName} must use http or https`);
  }
  return value;
}

/**
 * Validate an optional plain-text string field: type, length, and a strip of
 * control characters that have no legitimate use in a short label/caption.
 */
function assertOptionalText(value, fieldName, { maxLength = 500 } = {}) {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') {
    throw new ValidationError(`${fieldName} must be a string`);
  }
  if (value.length > maxLength) {
    throw new ValidationError(`${fieldName} must be at most ${maxLength} characters`);
  }
  // Strip control/non-printable characters (except normal whitespace) —
  // these have no legitimate use in a caption and can be used to smuggle
  // prompt-injection formatting or hide payloads from casual review.
  // eslint-disable-next-line no-control-regex
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
}

/**
 * Validate a field against an allow-list of exact values.
 */
function assertEnum(value, fieldName, allowedValues) {
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string' || !allowedValues.includes(value)) {
    throw new ValidationError(`${fieldName} must be one of: ${allowedValues.join(', ')}`);
  }
  return value;
}

/**
 * Reject any request body that isn't a plain object, or that contains keys
 * outside the expected schema. This is the "reject unexpected fields" OWASP
 * recommendation — it prevents mass-assignment style surprises if this
 * endpoint's logic is extended later without updating validation.
 */
function assertNoExtraFields(body, allowedKeys) {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) {
    throw new ValidationError('Request body must be a JSON object');
  }
  const extra = Object.keys(body).filter(k => !allowedKeys.includes(k));
  if (extra.length > 0) {
    throw new ValidationError(`Unexpected field(s): ${extra.join(', ')}`);
  }
}

export { ValidationError, assertHttpUrl, assertOptionalText, assertEnum, assertNoExtraFields };
